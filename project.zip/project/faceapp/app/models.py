from django.db import models
import os
from django.urls import path, include
import face_recognition
import cv2 
# Create your models here.


def faceCaptureSave(username):
        cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)   # 0 -> index of camera
        s, frame = cam.read()
        img_counter = 0
        img=""
        if s:    # frame captured without any errors
                cv2.namedWindow("cam-test")
                cv2.imshow("cam-test",frame)
                #cv2.waitKey(0)
                cv2.destroyWindow("cam-test")
                img="media/{}.png".format(username)
                cv2.imwrite(img, frame)
                print("{} written!".format(img))
                img_counter += 1
                print(1)
                img = str(img)
                return img
                

face_1_face_encoding=""
def facerecognize(user):
        
        try:
                cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)   # 0 -> index of camera
                s, img = cam.read()
                if s:    
                        # frame captured without any errors
                        cv2.namedWindow("cam-test")
                        cv2.imshow("cam-test",img)
                        #cv2.waitKey(0)s
                        cv2.destroyWindow("cam-test")
                        
                        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                        MEDIA_ROOT =os.path.join(BASE_DIR,'faceapp')

                        userimg = user+".png"
                        loc="media/"+userimg
                        face_1_image = face_recognition.load_image_file(loc)
                        face_1_face_encoding = face_recognition.face_encodings(face_1_image)[0]

                
                        small_frame = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
                        
                        rgb_small_frame = small_frame[:, :, ::-1]
                
                        face_locations = face_recognition.face_locations(rgb_small_frame)
                        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                        check=face_recognition.compare_faces(face_1_face_encoding, face_encodings)


        except :
                check = False
        
        if check[0]:
                return True

        else :
                return False    
